import { test, expect, type Page, Locator } from '@playwright/test';

/* Visit https://www.youtube.com/watch?v=ssAcJApCApk for PPM ts tutorial */ 

export class LoginPage{
    readonly page: Page;
    readonly txt_Username: Locator;
    readonly txt_Password: Locator;
    readonly btn_Login: Locator;

    constructor(page: Page){
        this.page=page;

        this.txt_Username=page.locator("input[name='userName']");
        this.txt_Password=page.locator("//input[@name='password']");
        this.btn_Login= page.locator("//input[@name='submit']");

    }

     //Open the application
     async rc_OpenApplication() {

        //Open the application
        await this.page.goto("https://demo.guru99.com/test/newtours/index.php")
    }

    //Login

    async rc_Login(username: string, password: string) {

        //Enter username
        await this.txt_Username.fill(username)
        //Enter password
        await this.txt_Password.fill(password)
        //Click login
        await this.btn_Login.click()
    }
}

    


