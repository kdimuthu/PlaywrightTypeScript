import { test, expect, type Page, Locator } from '@playwright/test';

export class HomePage{

    readonly page: Page;
    readonly msg_LoginSuccess: Locator;
    

    constructor(page: Page){
        this.page=page;

        this.msg_LoginSuccess=page.locator("//h3");
        
    }

    //Verify login success
    async rc_VerifyLoginSuccess() {

        //Verify login success
        await expect(this.msg_LoginSuccess).toHaveText("Login Successfully");
    }  

}

    


