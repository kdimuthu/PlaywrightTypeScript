import { test, expect } from '@playwright/test';
import { LoginPage } from '../Pages/loginpage';
import { HomePage } from '../Pages/homepage';
import {login} from '../testdata/testdata.json'

//Login to demo application
test.only("login to application", async ({ page }) => {

    const _LoginPage = new LoginPage(page)
    //Open application
    await _LoginPage.rc_OpenApplication()
    //Login
    await _LoginPage.rc_Login(login[0].username,login[0].password)
    const _HomePage = new HomePage(page)
    await _HomePage.rc_VerifyLoginSuccess()

  });